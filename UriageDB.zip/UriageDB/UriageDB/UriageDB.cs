﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Text.RegularExpressions;


namespace UriageDB
{
    public partial class UriageDB : Form
    {

        public string pgsqlstr1 =
                             "Dsn=UriageDB;" +
                             "Server =localhost;" +
                             "Port = 5432;" +
                             "User id=postgres;" +
                             "Pwd=postgres;" +
                             "DataBase=Uriage1";

        //データを詰め込む空行列
        private DataSet uriageDS1 = new DataSet();

        public string[] DTname = { "Uriagedb", "pricelist" };

        public UriageDB()
        {
            InitializeComponent();

            ControlBox = false;
        }

        private void dgvUriageDB_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvPriceList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbSoldName_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbSoldNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbSubTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void UriageDB_Load(object sender, EventArgs e)
        {

        }

        private void btnUriageDel_Click(object sender, EventArgs e)
        {
        }


        private void tbSoldPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUriageRead_Click(object sender, EventArgs e)
        {
            //データを詰め込む空行列
            //共通の格納先
            DataSet uriageDS1 = new DataSet();

            //DBへのアクセス設定
            //uriagedb
            OdbcConnection uriagecon0 = new OdbcConnection(pgsqlstr1);

            string uriagesql1 = "select * from "+ DTname[0];

            OdbcCommand uriagecon1 = new OdbcCommand();

            uriagecon1.CommandText = uriagesql1;

            uriagecon1.Connection = uriagecon0;

            OdbcDataAdapter uriageAD1 = new OdbcDataAdapter(uriagecon1);


            //DBへのアクセス設定
            //Pricelist
            OdbcConnection uriagecon00 = new OdbcConnection(pgsqlstr1);

            string uriagesql11 = "select * from " + DTname[1];

            OdbcCommand uriagecon2 = new OdbcCommand();

            uriagecon2.CommandText = uriagesql11;

            uriagecon2.Connection = uriagecon00;

            OdbcDataAdapter uriageAD11 = new OdbcDataAdapter(uriagecon2);


            //uriagedb:テーブル
            DataTable uriageDT1 = new DataTable();

            uriageDT1.TableName = DTname[0];

            uriageDS1.Tables.Add(uriageDT1);

            uriageAD1.Fill(uriageDS1.Tables[DTname[0]]);

            dgvUriageDB.RowCount = uriageDS1.Tables[DTname[0]].Rows.Count;

            for (int i = 0; i < dgvUriageDB.RowCount; i++)
            {
                for (int j = 0; j < 4; j++)
                {

                    var element1 = uriageDS1.Tables[DTname[0]].Rows[i][j];

                    dgvUriageDB.Rows[i].Cells[j].Value = element1;
                }

                //インデックス                
                dgvUriageDB.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }

            //pricelist テーブル
            DataTable uriageDT11 = new DataTable();

            uriageDT11.TableName = DTname[1];

            uriageDS1.Tables.Add(uriageDT11);

            uriageAD11.Fill(uriageDS1.Tables[DTname[1]]);

            dgvPriceList.RowCount = uriageDS1.Tables[DTname[1]].Rows.Count;

            for (int i = 0; i < dgvPriceList.RowCount; i++)
            {
                for (int j = 0; j < 3; j++)
                {

                    var element1 = uriageDS1.Tables[DTname[1]].Rows[i][j];

                    dgvPriceList.Rows[i].Cells[j].Value = element1;
                }

                //インデックス                
                dgvPriceList.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }
        }

        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}

