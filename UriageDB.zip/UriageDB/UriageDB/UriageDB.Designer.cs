﻿namespace UriageDB
{
    partial class UriageDB
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.dgvUriageDB = new System.Windows.Forms.DataGridView();
            this.uriageid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uriagename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uriagenumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uriageprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uriagesubtotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbSoldName = new System.Windows.Forms.TextBox();
            this.tbListPrice = new System.Windows.Forms.TextBox();
            this.tbSubTotal = new System.Windows.Forms.TextBox();
            this.tbSoldNumber = new System.Windows.Forms.TextBox();
            this.tbSoldNo = new System.Windows.Forms.TextBox();
            this.dgvPriceList = new System.Windows.Forms.DataGridView();
            this.listid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDirOpen = new System.Windows.Forms.Button();
            this.btnDBColAdd = new System.Windows.Forms.Button();
            this.btnDBColDel = new System.Windows.Forms.Button();
            this.btnListColDel = new System.Windows.Forms.Button();
            this.btnListColAdd = new System.Windows.Forms.Button();
            this.tbSoldPrice = new System.Windows.Forms.TextBox();
            this.tbListNum = new System.Windows.Forms.TextBox();
            this.btnUriageEntry = new System.Windows.Forms.Button();
            this.btnUriageDel = new System.Windows.Forms.Button();
            this.btnUriageRead = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUriageDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPriceList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnClose.Location = new System.Drawing.Point(815, 412);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 39);
            this.btnClose.TabIndex = 0;
            this.btnClose.TabStop = false;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dgvUriageDB
            // 
            this.dgvUriageDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUriageDB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uriageid,
            this.uriagename,
            this.uriagenumber,
            this.uriageprice,
            this.uriagesubtotal});
            this.dgvUriageDB.Location = new System.Drawing.Point(12, 12);
            this.dgvUriageDB.Name = "dgvUriageDB";
            this.dgvUriageDB.RowTemplate.Height = 21;
            this.dgvUriageDB.Size = new System.Drawing.Size(567, 259);
            this.dgvUriageDB.TabIndex = 1;
            this.dgvUriageDB.TabStop = false;
            this.dgvUriageDB.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUriageDB_CellContentClick);
            // 
            // uriageid
            // 
            this.uriageid.HeaderText = "ID";
            this.uriageid.Name = "uriageid";
            // 
            // uriagename
            // 
            this.uriagename.HeaderText = "Name";
            this.uriagename.Name = "uriagename";
            // 
            // uriagenumber
            // 
            this.uriagenumber.HeaderText = "Number";
            this.uriagenumber.Name = "uriagenumber";
            // 
            // uriageprice
            // 
            this.uriageprice.HeaderText = "Price";
            this.uriageprice.Name = "uriageprice";
            // 
            // uriagesubtotal
            // 
            this.uriagesubtotal.HeaderText = "SubTotal";
            this.uriagesubtotal.Name = "uriagesubtotal";
            // 
            // tbSoldName
            // 
            this.tbSoldName.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSoldName.Location = new System.Drawing.Point(12, 368);
            this.tbSoldName.Name = "tbSoldName";
            this.tbSoldName.Size = new System.Drawing.Size(197, 39);
            this.tbSoldName.TabIndex = 2;
            this.tbSoldName.TabStop = false;
            this.tbSoldName.Text = "売上品目";
            this.tbSoldName.TextChanged += new System.EventHandler(this.tbSoldName_TextChanged);
            // 
            // tbListPrice
            // 
            this.tbListPrice.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbListPrice.Location = new System.Drawing.Point(685, 322);
            this.tbListPrice.Name = "tbListPrice";
            this.tbListPrice.Size = new System.Drawing.Size(171, 39);
            this.tbListPrice.TabIndex = 3;
            this.tbListPrice.TabStop = false;
            this.tbListPrice.Text = "単価";
            this.tbListPrice.TextChanged += new System.EventHandler(this.tbPrice_TextChanged);
            // 
            // tbSubTotal
            // 
            this.tbSubTotal.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSubTotal.Location = new System.Drawing.Point(295, 324);
            this.tbSubTotal.Name = "tbSubTotal";
            this.tbSubTotal.Size = new System.Drawing.Size(184, 39);
            this.tbSubTotal.TabIndex = 4;
            this.tbSubTotal.TabStop = false;
            this.tbSubTotal.Text = "売上小計";
            this.tbSubTotal.TextChanged += new System.EventHandler(this.tbSubTotal_TextChanged);
            // 
            // tbSoldNumber
            // 
            this.tbSoldNumber.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSoldNumber.Location = new System.Drawing.Point(115, 323);
            this.tbSoldNumber.Name = "tbSoldNumber";
            this.tbSoldNumber.Size = new System.Drawing.Size(174, 39);
            this.tbSoldNumber.TabIndex = 5;
            this.tbSoldNumber.TabStop = false;
            this.tbSoldNumber.Text = "売上個数";
            this.tbSoldNumber.TextChanged += new System.EventHandler(this.tbSoldNumber_TextChanged);
            // 
            // tbSoldNo
            // 
            this.tbSoldNo.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSoldNo.Location = new System.Drawing.Point(12, 323);
            this.tbSoldNo.Name = "tbSoldNo";
            this.tbSoldNo.Size = new System.Drawing.Size(97, 39);
            this.tbSoldNo.TabIndex = 6;
            this.tbSoldNo.TabStop = false;
            this.tbSoldNo.Text = "No.";
            this.tbSoldNo.TextChanged += new System.EventHandler(this.tbNo_TextChanged);
            // 
            // dgvPriceList
            // 
            this.dgvPriceList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPriceList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.listid,
            this.listname,
            this.listprice});
            this.dgvPriceList.Location = new System.Drawing.Point(585, 12);
            this.dgvPriceList.Name = "dgvPriceList";
            this.dgvPriceList.RowTemplate.Height = 21;
            this.dgvPriceList.Size = new System.Drawing.Size(355, 259);
            this.dgvPriceList.TabIndex = 7;
            this.dgvPriceList.TabStop = false;
            this.dgvPriceList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPriceList_CellContentClick);
            // 
            // listid
            // 
            this.listid.HeaderText = "ID";
            this.listid.Name = "listid";
            // 
            // listname
            // 
            this.listname.HeaderText = "Name";
            this.listname.Name = "listname";
            // 
            // listprice
            // 
            this.listprice.HeaderText = "Price";
            this.listprice.Name = "listprice";
            // 
            // btnDirOpen
            // 
            this.btnDirOpen.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDirOpen.Location = new System.Drawing.Point(395, 412);
            this.btnDirOpen.Name = "btnDirOpen";
            this.btnDirOpen.Size = new System.Drawing.Size(184, 39);
            this.btnDirOpen.TabIndex = 8;
            this.btnDirOpen.TabStop = false;
            this.btnDirOpen.Text = "フォルダを開く";
            this.btnDirOpen.UseVisualStyleBackColor = true;
            // 
            // btnDBColAdd
            // 
            this.btnDBColAdd.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDBColAdd.Location = new System.Drawing.Point(96, 278);
            this.btnDBColAdd.Name = "btnDBColAdd";
            this.btnDBColAdd.Size = new System.Drawing.Size(118, 39);
            this.btnDBColAdd.TabIndex = 10;
            this.btnDBColAdd.TabStop = false;
            this.btnDBColAdd.Text = "列追加";
            this.btnDBColAdd.UseVisualStyleBackColor = true;
            // 
            // btnDBColDel
            // 
            this.btnDBColDel.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDBColDel.Location = new System.Drawing.Point(220, 277);
            this.btnDBColDel.Name = "btnDBColDel";
            this.btnDBColDel.Size = new System.Drawing.Size(105, 39);
            this.btnDBColDel.TabIndex = 11;
            this.btnDBColDel.TabStop = false;
            this.btnDBColDel.Text = "列削除";
            this.btnDBColDel.UseVisualStyleBackColor = true;
            // 
            // btnListColDel
            // 
            this.btnListColDel.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnListColDel.Location = new System.Drawing.Point(785, 277);
            this.btnListColDel.Name = "btnListColDel";
            this.btnListColDel.Size = new System.Drawing.Size(97, 39);
            this.btnListColDel.TabIndex = 13;
            this.btnListColDel.TabStop = false;
            this.btnListColDel.Text = "列削除";
            this.btnListColDel.UseVisualStyleBackColor = true;
            // 
            // btnListColAdd
            // 
            this.btnListColAdd.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnListColAdd.Location = new System.Drawing.Point(685, 278);
            this.btnListColAdd.Name = "btnListColAdd";
            this.btnListColAdd.Size = new System.Drawing.Size(94, 39);
            this.btnListColAdd.TabIndex = 12;
            this.btnListColAdd.TabStop = false;
            this.btnListColAdd.Text = "列追加";
            this.btnListColAdd.UseVisualStyleBackColor = true;
            // 
            // tbSoldPrice
            // 
            this.tbSoldPrice.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSoldPrice.Location = new System.Drawing.Point(215, 368);
            this.tbSoldPrice.Name = "tbSoldPrice";
            this.tbSoldPrice.Size = new System.Drawing.Size(171, 39);
            this.tbSoldPrice.TabIndex = 14;
            this.tbSoldPrice.TabStop = false;
            this.tbSoldPrice.Text = "単価";
            this.tbSoldPrice.TextChanged += new System.EventHandler(this.tbSoldPrice_TextChanged);
            // 
            // tbListNum
            // 
            this.tbListNum.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbListNum.Location = new System.Drawing.Point(585, 322);
            this.tbListNum.Name = "tbListNum";
            this.tbListNum.Size = new System.Drawing.Size(97, 39);
            this.tbListNum.TabIndex = 15;
            this.tbListNum.TabStop = false;
            this.tbListNum.Text = "No.";
            // 
            // btnUriageEntry
            // 
            this.btnUriageEntry.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnUriageEntry.Location = new System.Drawing.Point(12, 413);
            this.btnUriageEntry.Name = "btnUriageEntry";
            this.btnUriageEntry.Size = new System.Drawing.Size(118, 39);
            this.btnUriageEntry.TabIndex = 16;
            this.btnUriageEntry.TabStop = false;
            this.btnUriageEntry.Text = "登録";
            this.btnUriageEntry.UseVisualStyleBackColor = true;
            // 
            // btnUriageDel
            // 
            this.btnUriageDel.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnUriageDel.Location = new System.Drawing.Point(136, 412);
            this.btnUriageDel.Name = "btnUriageDel";
            this.btnUriageDel.Size = new System.Drawing.Size(118, 39);
            this.btnUriageDel.TabIndex = 17;
            this.btnUriageDel.TabStop = false;
            this.btnUriageDel.Text = "登録削除";
            this.btnUriageDel.UseVisualStyleBackColor = true;
            this.btnUriageDel.Click += new System.EventHandler(this.btnUriageDel_Click);
            // 
            // btnUriageRead
            // 
            this.btnUriageRead.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnUriageRead.Location = new System.Drawing.Point(448, 279);
            this.btnUriageRead.Name = "btnUriageRead";
            this.btnUriageRead.Size = new System.Drawing.Size(163, 39);
            this.btnUriageRead.TabIndex = 18;
            this.btnUriageRead.TabStop = false;
            this.btnUriageRead.Text = "読込";
            this.btnUriageRead.UseVisualStyleBackColor = true;
            this.btnUriageRead.Click += new System.EventHandler(this.btnUriageRead_Click);
            // 
            // UriageDB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(952, 481);
            this.Controls.Add(this.btnUriageRead);
            this.Controls.Add(this.btnUriageDel);
            this.Controls.Add(this.btnUriageEntry);
            this.Controls.Add(this.tbListNum);
            this.Controls.Add(this.tbSoldPrice);
            this.Controls.Add(this.btnListColDel);
            this.Controls.Add(this.btnListColAdd);
            this.Controls.Add(this.btnDBColDel);
            this.Controls.Add(this.btnDBColAdd);
            this.Controls.Add(this.btnDirOpen);
            this.Controls.Add(this.dgvPriceList);
            this.Controls.Add(this.tbSoldNo);
            this.Controls.Add(this.tbSoldNumber);
            this.Controls.Add(this.tbSubTotal);
            this.Controls.Add(this.tbListPrice);
            this.Controls.Add(this.tbSoldName);
            this.Controls.Add(this.dgvUriageDB);
            this.Controls.Add(this.btnClose);
            this.Name = "UriageDB";
            this.Text = "UriageDB";
            this.Load += new System.EventHandler(this.UriageDB_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUriageDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPriceList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridView dgvUriageDB;
        private System.Windows.Forms.TextBox tbSoldName;
        private System.Windows.Forms.TextBox tbListPrice;
        private System.Windows.Forms.TextBox tbSubTotal;
        private System.Windows.Forms.TextBox tbSoldNumber;
        private System.Windows.Forms.TextBox tbSoldNo;
        private System.Windows.Forms.DataGridView dgvPriceList;
        private System.Windows.Forms.Button btnDirOpen;
        private System.Windows.Forms.Button btnDBColAdd;
        private System.Windows.Forms.Button btnDBColDel;
        private System.Windows.Forms.Button btnListColDel;
        private System.Windows.Forms.Button btnListColAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn uriageid;
        private System.Windows.Forms.DataGridViewTextBoxColumn uriagename;
        private System.Windows.Forms.DataGridViewTextBoxColumn uriagenumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn uriageprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn uriagesubtotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn listid;
        private System.Windows.Forms.DataGridViewTextBoxColumn listname;
        private System.Windows.Forms.DataGridViewTextBoxColumn listprice;
        private System.Windows.Forms.TextBox tbSoldPrice;
        private System.Windows.Forms.TextBox tbListNum;
        private System.Windows.Forms.Button btnUriageEntry;
        private System.Windows.Forms.Button btnUriageDel;
        private System.Windows.Forms.Button btnUriageRead;
    }
}

